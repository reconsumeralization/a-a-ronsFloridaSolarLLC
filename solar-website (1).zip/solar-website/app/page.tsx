'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { BenefitsInteractive } from '@/components/benefits-interactive'
import { CTASection } from '@/components/cta-section'
import { Button } from "@/components/ui/button"
import { ArrowRight, Sun, Shield, PenToolIcon as Tool, Zap } from 'lucide-react'
import Link from "next/link"
import Image from "next/image"

export default function Home() {
  const [activeFeature, setActiveFeature] = useState(0)

  const features = [
    {
      title: "Solar Panel Cleaning",
      description: "Professional cleaning to maintain optimal efficiency",
      icon: Sun,
      color: "from-yellow-400 to-orange-500",
    },
    {
      title: "System Maintenance",
      description: "Regular checkups and preventive maintenance",
      icon: Tool,
      color: "from-blue-400 to-blue-600",
    },
    {
      title: "Performance Optimization",
      description: "Maximize your solar system's output",
      icon: Zap,
      color: "from-green-400 to-green-600",
    },
    {
      title: "Licensed & Insured",
      description: "Professional service you can trust",
      icon: Shield,
      color: "from-purple-400 to-purple-600",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 md:py-24 lg:py-32 bg-gradient-to-b from-blue-900 to-blue-950 overflow-hidden">
        <div className="container px-4 md:px-6 relative z-10">
          <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
            <motion.div 
              className="flex flex-col justify-center space-y-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter text-white sm:text-5xl xl:text-6xl/none">
                  Professional Solar Maintenance & Cleaning
                </h1>
                <p className="max-w-[600px] text-blue-100 md:text-xl">
                  Keep your solar investment performing at its peak with our expert maintenance services
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button 
                  className="bg-blue-500 hover:bg-blue-600 text-white"
                  onClick={() => window.location.href = 'tel:3215062981'}
                >
                  Call Now
                </Button>
                <Button asChild variant="outline" className="border-blue-400 text-blue-400 hover:bg-blue-700">
                  <Link href="/contact">
                    Get a Quote
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </motion.div>
            <motion.div 
              className="relative hidden lg:block"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Image
                src="/placeholder.svg?height=600&width=400"
                alt="Solar Panels"
                width={400}
                height={600}
                className="rounded-lg object-cover"
                priority
              />
            </motion.div>
          </div>
        </div>
        <motion.div 
          className="absolute inset-0 bg-blue-900 opacity-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          transition={{ duration: 1 }}
        >
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Background"
            layout="fill"
            objectFit="cover"
            className="mix-blend-overlay"
          />
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-blue-900">
        <div className="container px-4 md:px-6">
          <motion.h2 
            className="text-3xl font-bold text-center text-white mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Our Services
          </motion.h2>
          <div className="grid gap-8 lg:grid-cols-4">
            {features.map((feature, i) => (
              <motion.div 
                key={i}
                className="relative"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                onMouseEnter={() => setActiveFeature(i)}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} rounded-lg opacity-75 transition-opacity duration-300 ${activeFeature === i ? 'opacity-100' : 'opacity-75'}`} />
                <div className="relative p-6 space-y-4">
                  <feature.icon className="h-12 w-12 text-white" />
                  <h3 className="text-xl font-bold text-white">{feature.title}</h3>
                  <p className="text-blue-100">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <BenefitsInteractive />
      
      {/* Testimonials Section */}
      <section className="py-20 bg-blue-950">
        <div className="container px-4 md:px-6">
          <motion.h2 
            className="text-3xl font-bold text-center text-white mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            What Our Customers Say
          </motion.h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                quote: "A-A-RONS Solar transformed our system's performance. Highly recommended!",
                author: "John D.",
                location: "Orlando, FL"
              },
              {
                quote: "Professional, punctual, and thorough. Our panels have never looked better!",
                author: "Sarah M.",
                location: "Tampa, FL"
              },
              {
                quote: "The difference in our energy production after their cleaning was remarkable.",
                author: "Michael R.",
                location: "Miami, FL"
              }
            ].map((testimonial, i) => (
              <motion.div 
                key={i}
                className="bg-blue-900 p-6 rounded-lg shadow-lg"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
              >
                <p className="text-blue-100 mb-4">"{testimonial.quote}"</p>
                <p className="text-blue-300 font-semibold">{testimonial.author}</p>
                <p className="text-blue-400 text-sm">{testimonial.location}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </div>
  )
}

