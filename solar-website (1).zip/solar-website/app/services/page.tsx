'use client'

import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Sun, Droplet, PenToolIcon as Tool, Shield, ArrowRight } from 'lucide-react'
import Link from "next/link"
import Image from "next/image"

const services = [
  {
    icon: Sun,
    title: "Solar Panel Cleaning",
    description: "Professional cleaning service to maintain optimal efficiency of your solar panels",
    link: "/services/solar-panel-cleaning"
  },
  {
    icon: Droplet,
    title: "Pool Solar Maintenance",
    description: "Comprehensive maintenance for pool solar heating systems",
    link: "/services/pool-solar-maintenance"
  },
  {
    icon: Tool,
    title: "PV Solar Repair",
    description: "Expert repair services for all types of solar systems",
    link: "/services/pv-solar-repair"
  },
  {
    icon: Shield,
    title: "System Inspections",
    description: "Thorough inspections to ensure your solar system's optimal performance",
    link: "/services/system-inspections"
  }
]

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-gradient-primary py-12">
      <div className="container px-4 md:px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-12"
        >
          <div className="space-y-4 text-center">
            <h1 className="text-4xl font-bold tracking-tighter text-white sm:text-5xl">Our Solar Services</h1>
            <p className="mx-auto max-w-[700px] text-zinc-200 md:text-xl">
              Comprehensive solar maintenance and repair services to keep your system running at peak efficiency
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2">
            {services.map((service, i) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
              >
                <Card className="bg-card-secondary border-highlight h-full transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/20 hover:scale-105">
                  <CardHeader>
                    <service.icon className="w-12 h-12 text-primary mb-4" />
                    <CardTitle className="text-2xl font-bold text-white">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-zinc-300">{service.description}</p>
                    <Button asChild variant="outline" className="button-secondary">
                      <Link href={service.link}>
                        Learn More
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="space-y-8"
          >
            <h2 className="text-3xl font-bold text-white text-center">Our Process</h2>
            <div className="grid gap-8 md:grid-cols-3">
              {[
                {
                  step: "01",
                  title: "Inspection",
                  description: "Thorough system evaluation and performance assessment"
                },
                {
                  step: "02",
                  title: "Maintenance",
                  description: "Professional cleaning and necessary repairs"
                },
                {
                  step: "03",
                  title: "Report",
                  description: "Detailed service report and recommendations"
                }
              ].map((step, i) => (
                <motion.div 
                  key={step.step}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.6 + i * 0.1 }}
                  className="space-y-2"
                >
                  <span className="text-4xl font-bold text-primary">{step.step}</span>
                  <h3 className="text-xl font-bold text-white">{step.title}</h3>
                  <p className="text-zinc-300">{step.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="text-center space-y-4"
          >
            <h2 className="text-2xl font-bold text-white">Ready to Optimize Your Solar System?</h2>
            <Button asChild className="button-primary">
              <Link href="/contact">Schedule Service</Link>
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}

