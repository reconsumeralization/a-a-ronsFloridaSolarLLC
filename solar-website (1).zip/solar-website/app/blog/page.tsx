import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from 'lucide-react'
import Link from "next/link"
import Image from "next/image"

const posts = [
  {
    id: 1,
    title: "Maximizing Solar Panel Efficiency Through Regular Maintenance",
    excerpt: "Learn how proper maintenance can increase your solar panel's efficiency by up to 25%",
    date: "2024-01-15",
    image: "/placeholder.svg?height=300&width=600",
    category: "Maintenance"
  },
  {
    id: 2,
    title: "The Impact of Florida Weather on Solar Panels",
    excerpt: "Understanding how Florida's unique climate affects your solar installation",
    date: "2024-01-10",
    image: "/placeholder.svg?height=300&width=600",
    category: "Education"
  },
  {
    id: 3,
    title: "Signs Your Pool Solar System Needs Maintenance",
    excerpt: "Key indicators that it's time for pool solar system maintenance",
    date: "2024-01-05",
    image: "/placeholder.svg?height=300&width=600",
    category: "Pool Solar"
  },
  {
    id: 4,
    title: "Solar Panel Cleaning: DIY vs Professional Service",
    excerpt: "Comparing the pros and cons of DIY and professional solar panel cleaning",
    date: "2024-01-01",
    image: "/placeholder.svg?height=300&width=600",
    category: "Tips"
  }
]

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-gradient-primary py-12">
      <div className="container px-4 md:px-6">
        <div className="space-y-12">
          <div className="space-y-4 text-center">
            <h1 className="text-4xl font-bold tracking-tighter text-white sm:text-5xl">Solar Maintenance Blog</h1>
            <p className="mx-auto max-w-[700px] text-secondary md:text-xl">
              Expert insights and tips for maintaining your solar investment
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {posts.map((post) => (
              <Card key={post.id} className="bg-card-secondary border-highlight overflow-hidden">
                <div className="relative h-48 w-full">
                  <Image
                    src={post.image}
                    alt={post.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <CardHeader>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    {new Date(post.date).toLocaleDateString()}
                    <span className="px-2 py-1 text-xs bg-blue-400/10 text-primary rounded-full">
                      {post.category}
                    </span>
                  </div>
                  <CardTitle className="text-xl font-bold text-white">{post.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-secondary">{post.excerpt}</p>
                  <Button asChild variant="link" className="mt-4 text-primary p-0">
                    <Link href={`/blog/${post.id}`}>
                      Read More →
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

