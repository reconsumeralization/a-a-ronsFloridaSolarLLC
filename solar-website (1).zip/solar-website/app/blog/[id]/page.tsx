import { Button } from "@/components/ui/button"
import { Calendar, ArrowLeft } from 'lucide-react'
import Link from "next/link"
import Image from "next/image"

const posts = [
  {
    id: 1,
    title: "Maximizing Solar Panel Efficiency Through Regular Maintenance",
    content: `
      <p>Solar panels are a significant investment in sustainable energy, but like any technology, they require proper care to function at their best. Regular maintenance is key to ensuring your solar panels operate at peak efficiency, potentially increasing their output by up to 25%.</p>
      
      <h2>Why Regular Maintenance Matters</h2>
      <p>Over time, solar panels can accumulate dust, dirt, pollen, and other debris. This buildup can significantly reduce the amount of sunlight that reaches the photovoltaic cells, decreasing energy production. In Florida's climate, factors like salt spray near coastal areas and pollen during certain seasons can exacerbate this issue.</p>
      
      <h2>Professional Cleaning vs. DIY</h2>
      <p>While some homeowners opt for DIY cleaning, professional maintenance offers several advantages:</p>
      <ul>
        <li>Safety: Professionals have the right equipment to safely clean roof-mounted panels.</li>
        <li>Expertise: They can identify and address potential issues beyond just cleaning.</li>
        <li>Efficiency: Professional-grade cleaning solutions and techniques ensure optimal results.</li>
      </ul>
      
      <h2>The A-A-RONS Approach</h2>
      <p>At A-A-RONS Florida Solar LLC, we use a comprehensive approach to solar panel maintenance:</p>
      <ol>
        <li>Visual Inspection: We check for any visible damage or issues.</li>
        <li>Gentle Cleaning: Using specialized solutions and soft brushes to avoid damage.</li>
        <li>Performance Check: We test the system's output before and after cleaning.</li>
        <li>Detailed Report: You'll receive a full report on your system's condition and performance.</li>
      </ol>
      
      <p>By maintaining your solar panels regularly, you're not just ensuring maximum energy production – you're also protecting your investment and extending the life of your system. Contact us today to schedule your maintenance service and start seeing the benefits of a well-maintained solar system.</p>
    `,
    date: "2024-01-15",
    image: "/placeholder.svg?height=400&width=800",
    category: "Maintenance"
  },
  // ... other blog posts
]

export default function BlogPost({ params }: { params: { id: string } }) {
  const post = posts.find(p => p.id === parseInt(params.id))

  if (!post) {
    return <div>Post not found</div>
  }

  return (
    <div className="min-h-screen bg-gradient-primary py-12">
      <div className="container px-4 md:px-6">
        <Button asChild variant="outline" className="mb-8 button-secondary">
          <Link href="/blog">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Blog
          </Link>
        </Button>

        <article className="prose prose-invert lg:prose-xl mx-auto">
          <h1 className="text-4xl font-bold tracking-tighter text-white sm:text-5xl mb-4">{post.title}</h1>
          
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
            <Calendar className="w-4 h-4" />
            {new Date(post.date).toLocaleDateString()}
            <span className="px-2 py-1 text-xs bg-blue-400/10 text-primary rounded-full">
              {post.category}
            </span>
          </div>

          <Image
            src={post.image}
            alt={post.title}
            width={800}
            height={400}
            className="rounded-lg object-cover mb-8"
          />

          <div dangerouslySetInnerHTML={{ __html: post.content }} />
        </article>
      </div>
    </div>
  )
}

