import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Facebook, Mail, Phone, MapPin } from 'lucide-react'

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-zinc-900">
      <div className="container px-4 py-16 md:px-6">
        <div className="space-y-12">
          <div className="space-y-4 text-center">
            <h1 className="text-4xl font-bold tracking-tighter text-yellow-400 sm:text-5xl">Contact Us</h1>
            <p className="mx-auto max-w-[700px] text-zinc-200 md:text-xl">
              Get in touch for professional solar maintenance and repair services
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2">
            <Card className="bg-zinc-800 border-yellow-400/20">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-yellow-200">Send Us a Message</CardTitle>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Input
                        placeholder="First Name"
                        className="bg-zinc-900 border-yellow-400/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <Input
                        placeholder="Last Name"
                        className="bg-zinc-900 border-yellow-400/20"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Input
                      type="email"
                      placeholder="Email"
                      className="bg-zinc-900 border-yellow-400/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <Input
                      type="tel"
                      placeholder="Phone"
                      className="bg-zinc-900 border-yellow-400/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <Input
                      placeholder="Service Type"
                      className="bg-zinc-900 border-yellow-400/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <Textarea
                      placeholder="Message"
                      className="min-h-[100px] bg-zinc-900 border-yellow-400/20"
                    />
                  </div>
                  <Button className="w-full bg-yellow-400 text-zinc-900 hover:bg-yellow-500">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>

            <div className="space-y-8">
              <Card className="bg-zinc-800 border-yellow-400/20">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-yellow-200">Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <Phone className="w-6 h-6 text-yellow-400" />
                    <div>
                      <p className="font-medium text-yellow-200">Phone</p>
                      <p className="text-zinc-300">(321) 506-2981</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <Mail className="w-6 h-6 text-yellow-400" />
                    <div>
                      <p className="font-medium text-yellow-200">Email</p>
                      <p className="text-zinc-300">A.A.RonsHomeImprovement321@gmail.com</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <Facebook className="w-6 h-6 text-yellow-400" />
                    <div>
                      <p className="font-medium text-yellow-200">Facebook</p>
                      <p className="text-zinc-300">A A-Ron&apos;s Home Repair and Renovations</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <MapPin className="w-6 h-6 text-yellow-400" />
                    <div>
                      <p className="font-medium text-yellow-200">Service Area</p>
                      <p className="text-zinc-300">Florida</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-zinc-800 border-yellow-400/20">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-yellow-200">Business Hours</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-zinc-300">Monday - Friday</span>
                      <span className="text-yellow-200">8:00 AM - 6:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-300">Saturday</span>
                      <span className="text-yellow-200">9:00 AM - 4:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-300">Sunday</span>
                      <span className="text-yellow-200">Closed</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

