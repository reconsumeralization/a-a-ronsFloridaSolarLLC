import { Button } from "@/components/ui/button"
import { ArrowRight } from 'lucide-react'
import Link from "next/link"

export function CTASection() {
  return (
    <section className="bg-gradient-to-b from-blue-800 to-blue-900 py-16">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter text-white sm:text-4xl md:text-5xl">
            Ready to Optimize Your Solar Investment?
          </h2>
          <p className="mx-auto max-w-[700px] text-blue-100 md:text-xl">
            Get professional solar maintenance and cleaning services. Current Florida solar customers get a 10% discount!
          </p>
          <div className="flex flex-col gap-4 min-[400px]:flex-row">
            <Button 
              className="bg-blue-500 hover:bg-blue-600 text-white"
              onClick={() => window.location.href = 'tel:3215062981'}
            >
              Call Now
            </Button>
            <Button asChild variant="outline" className="border-blue-400 text-blue-400 hover:bg-blue-700">
              <Link href="/contact">
                Schedule Service
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

