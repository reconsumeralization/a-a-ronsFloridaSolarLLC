export function Footer() {
  return (
    <footer className="py-6 bg-zinc-900">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-sm text-zinc-400">
            © 2024 A A-Ron&apos;s Home Improvement and Repair LLC. All rights reserved.
          </p>
          <p className="text-sm text-zinc-400">
            Licensed and Insured
          </p>
        </div>
      </div>
    </footer>
  )
}

